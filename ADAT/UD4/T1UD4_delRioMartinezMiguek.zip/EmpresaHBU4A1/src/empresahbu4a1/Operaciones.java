/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package empresahbu4a1;

import java.text.SimpleDateFormat;
import java.util.*;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.annotations.Sort;
import pojos.*;

/**
 * @author Miguel del Río
 */
public class Operaciones {

    public static Session iniciarSesion() {
        Session sesion = HibernateUtil.getSessionFactory().openSession();
        return sesion;
    }

    public static void cerrarSesion(Session sesion) {
        if (sesion != null) {
            sesion.close();
        }
    }

    public static <T> void insertarObjeto(T objeto) {
        Session sesion = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = sesion.beginTransaction();
            sesion.save(objeto);
            tx.commit();
        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }

    public static void getDepartamento(int numDepartamento) {
        try {
            Session session = iniciarSesion();
            Departamento departamento = (Departamento) session.load(Departamento.class, numDepartamento);
            System.out.println(departamento.getNumDepartamento());
            System.out.println(departamento.getNomeDepartamento());
        } catch (Exception e) {
            System.out.println("No se ha encontrado el departamento " + numDepartamento);
        }

    }

    public static void getEmpleado(String nss) {
        try {
            Session session = iniciarSesion();
            Empregado empregado = (Empregado) session.load(Empregado.class, nss);
            System.out.println(empregado.getNss());
            System.out.println(empregado.getNome() + " " + empregado.getApelido1() + " " + empregado.getApelido2());
        } catch (Exception e) {
            System.out.println("No se ha encontrado el empleado " + nss);
        }

    }

    public static void borrarDepartamento(int numDepartamento, Session sesion) {
        Transaction tx = null;

        Departamento dep = (Departamento) sesion.get(Departamento.class, numDepartamento);

        try {
            tx = sesion.beginTransaction();
            sesion.delete(dep);
            tx.commit();
        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }

    public static void borrarEmpleado(String nss, Session sesion) {
        Transaction tx = null;

        //Departamento dep = new Departamento(numDepartamento, "");

        Empregado emp = new Empregado(nss, "", "");

        try {
            tx = sesion.beginTransaction();
            sesion.delete(emp);
            tx.commit();
        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }

    public static void cambiarNombreDepartamento(int numDepartamento, String nuevoNombre, Session sesion) {
        Transaction tx = null;

        try {
            tx = sesion.beginTransaction();
            Departamento dep = (Departamento) sesion.get(Departamento.class, numDepartamento);
            dep.setNomeDepartamento(nuevoNombre);
            //sesion.update(dep);
            tx.commit();
        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }

    /*
    public static void insertarTelefonoEmpleado(String nss, String telefono, Session sesion) {

        Transaction tx = null;

        try {
            Empregado emp = (Empregado) sesion.get(Empregado.class, nss);
            
            if (emp != null) {
                Set<String> telefonos = emp.getTelefonos();
                telefonos.add(telefono);
                
                // No es necesario porque cojo una referencia al set 
                //emp.setTelefonos(telefonos);

                try {
                    tx = sesion.beginTransaction();
                    tx.commit();
                } catch (HibernateException e) {
                    System.out.println("No ha funcionado " + e.getMessage());
                    if (tx != null) {
                        tx.rollback();
                    }
                }
            }

        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }

    public static void borrarTelefonoEmpleado(String nss, String telefono, Session sesion) {
        Transaction tx = null;

        try {
            Empregado emp = (Empregado) sesion.get(Empregado.class, nss);

            if (emp != null) {
                Set<String> telefonos = emp.getTelefonos();
                telefonos.remove(telefono);

                // No es necesario porque cojo una referencia al set
                //emp.setTelefonos(telefonos);

                try {
                    tx = sesion.beginTransaction();
                    tx.commit();
                } catch (HibernateException e) {
                    System.out.println("No ha funcionado " + e.getMessage());
                    if (tx != null) {
                        tx.rollback();
                    }
                }
            }

        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }
     */

    //--------------------------------------------------------------------------

    public static void insertarEmpleado(Empregado emp, Session sesion) {
        Transaction tx = null;

        try {
            tx = sesion.beginTransaction();
            sesion.save(emp);
            tx.commit();
        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }

    public static void insertarDepartamento(Departamento dep, Session sesion) {
        Transaction tx = null;

        try {
            tx = sesion.beginTransaction();
            sesion.save(dep);
            tx.commit();
        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }

    public static void insertarDepartamentoNombre(String nombre, Session sesion) {
        Transaction tx = null;

        Departamento dep = new Departamento(0, nombre);

        try {
            tx = sesion.beginTransaction();
            sesion.save(dep);
            tx.commit();
        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }

    //--------------------------------------------------------------------------

    public static void insertarFamiliar(String nss, Familiar familiar, Session session) {
        Transaction tx = null;

        Empregado emp = (Empregado) session.get(Empregado.class, nss);

        if (emp != null) {
            emp.getFamiliares().add(familiar);

            try {
                tx = session.beginTransaction();
                tx.commit();
                System.out.println("Familiar insertado correctamente.");
            } catch (HibernateException e) {
                if (tx != null) {
                    tx.rollback();
                }
                System.out.println("Error al insertar. " + e.getMessage());
            }
        }

    }

    public static void insertarFamiliarFix(String nss, Familiar familiar, Session session) {
        Transaction tx = null;

        Empregado emp = (Empregado) session.get(Empregado.class, nss);

        if (emp != null) {
            //familiar.setNumero(emp.getFamiliares().size() + 1);
            emp.getFamiliares().add(familiar);

            try {
                tx = session.beginTransaction();
                tx.commit();
                System.out.println("Familiar insertado correctamente.");
            } catch (HibernateException e) {
                if (tx != null) {
                    tx.rollback();
                }
                System.out.println("Error al insertar. " + e.getMessage());
            }
        }

    }

    public static void insertarAficion(String nss, String aficion, Session sesion) {

        Transaction tx = null;

        try {
            Empregado emp = (Empregado) sesion.get(Empregado.class, nss);

            if (emp != null) {

                //Collection<String> aficiones = emp.getAficiones();
                //aficiones.add(aficion);
                // MEJOR ASI HOME
                emp.getAficiones().add(aficion);

                // No es necesario porque cojo una referencia al set
                //emp.setTelefonos(telefonos);

                try {
                    tx = sesion.beginTransaction();
                    tx.commit();
                } catch (HibernateException e) {
                    System.out.println("No ha funcionado " + e.getMessage());
                    if (tx != null) {
                        tx.rollback();
                    }
                }
            }

        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }

    public static void insertarLugar(int numDpto, String lugar, Session sesion) {
        Transaction tx = null;

        try {
            Departamento dep = (Departamento) sesion.get(Departamento.class, numDpto);

            if (dep != null) {
                //Collection<String> aficiones = emp.getAficiones();
                //aficiones.add(aficion);
                // MEJOR ASI HOME
                dep.getLugares().add(lugar);

                // No es necesario porque cojo una referencia al set
                //emp.setTelefonos(telefonos);

                try {
                    tx = sesion.beginTransaction();
                    tx.commit();
                } catch (HibernateException e) {
                    System.out.println("No ha funcionado " + e.getMessage());
                    if (tx != null) {
                        tx.rollback();
                    }
                }
            }

        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }

    public static void insertarHorasExtras(String nss, Date data, Double horas, Session sesion) {
        Transaction tx = null;

        try {
            Empregado emp = (Empregado) sesion.get(Empregado.class, nss);

            if (emp != null) {
                SortedMap<Date, Double> listaHoras = emp.getHorasextras();
                listaHoras.put(data, horas);
                emp.setHorasextras(listaHoras);

                try {
                    tx = sesion.beginTransaction();
                    tx.commit();
                } catch (HibernateException e) {
                    System.out.println("No ha funcionado " + e.getMessage());
                    if (tx != null) {
                        tx.rollback();
                    }
                }
            }

        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }

    public static void visualizasHorasExtrasEmpleado(String nss, Session sesion) {
        Transaction tx = null;

        try {
            Empregado emp = (Empregado) sesion.get(Empregado.class, nss);

            if (emp != null) {
                SortedMap<Date, Double> listaHoras = emp.getHorasextras();

                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                StringBuilder sb = new StringBuilder();

                for (Date fecha : listaHoras.keySet()) {
                    double horas = listaHoras.get(fecha);
                    sb.append(sdf.format(fecha))
                            .append(" ")
                            .append((Double) horas)
                            .append(" horas\n");
                }

                System.out.println(sb);

                try {
                    tx = sesion.beginTransaction();
                    tx.commit();
                } catch (HibernateException e) {
                    System.out.println("No ha funcionado " + e.getMessage());
                    if (tx != null) {
                        tx.rollback();
                    }
                }
            }

        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }

    public static void insertarVehiculo(String nss, Vehiculo vehiculo, Session session) {
        Transaction tx = null;

        Empregado emp = (Empregado) session.get(Empregado.class, nss);

        if (emp != null) {
            emp.setVehiculo(vehiculo);
            vehiculo.setEmpregado(emp);

            try {
                tx = session.beginTransaction();
                tx.commit();
                System.out.println("Vehiculo insertado correctamente.");
            } catch (HibernateException e) {
                if (tx != null) {
                    tx.rollback();
                }
                System.out.println("Error al insertar. " + e.getMessage());
            }
        }

    }

    public static void visualizarProyectosDptoProPlus(String nomeDepartamento, Session sesion) {
        Transaction tx = null;

        try {
            Departamento dep = (Departamento) sesion.createQuery("from Departamento d where d.nomeDepartamento = :name")
                    .setString("name", nomeDepartamento)
                    .list().get(0);

            if (dep != null) {
                Collection<Proxecto> listaProxectos = dep.getProxectos();

                StringBuilder sb = new StringBuilder();

                for (var e : listaProxectos) {
                    sb.append(e.getNomeProxecto());
                }

                System.out.println(sb);

                try {
                    tx = sesion.beginTransaction();
                    tx.commit();
                } catch (HibernateException e) {
                    System.out.println("No ha funcionado " + e.getMessage());
                    if (tx != null) {
                        tx.rollback();
                    }
                }
            }

        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }


    public static void visualizarProyectosDpto(int numDepartamento, Session sesion) {
        Transaction tx = null;

        try {
            Departamento dep = (Departamento) sesion.get(Departamento.class, numDepartamento);

            if (dep != null) {
                Collection<Proxecto> listaProxectos = dep.getProxectos();

                StringBuilder sb = new StringBuilder();

                for (var e : listaProxectos) {
                    sb.append(e.getNomeProxecto());
                }

                System.out.println(sb);

                try {
                    tx = sesion.beginTransaction();
                    tx.commit();
                } catch (HibernateException e) {
                    System.out.println("No ha funcionado " + e.getMessage());
                    if (tx != null) {
                        tx.rollback();
                    }
                }
            }

        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }


    public static void asignarEmpregadoProxecto(String nss, int numProxecto, Session sesion) {
        Transaction tx = null;

        try {
            Empregado emp = (Empregado) sesion.get(Empregado.class, nss);
            Proxecto pr = (Proxecto) sesion.get(Proxecto.class, numProxecto);

            if (emp != null) {
                if (emp.getProxectos().contains(pr)) {
                    System.out.println("Ya está en el proyecto");
                    return;
                }

                emp.getProxectos().add(pr);
                pr.getEmpregados().add(emp);

                try {
                    tx = sesion.beginTransaction();
                    tx.commit();
                } catch (HibernateException e) {
                    System.out.println("No ha funcionado " + e.getMessage());
                    if (tx != null) {
                        tx.rollback();
                    }
                }
            }

        } catch (HibernateException e) {
            System.out.println("No ha funcionado " + e.getMessage());
            if (tx != null) {
                tx.rollback();
            }
        }
    }


}
