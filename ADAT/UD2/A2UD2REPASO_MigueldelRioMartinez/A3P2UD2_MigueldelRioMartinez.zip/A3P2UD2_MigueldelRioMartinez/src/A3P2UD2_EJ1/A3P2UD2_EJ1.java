package A3P2UD2_EJ1;

import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.*;

public class A3P2UD2_EJ1 {
    public static void main(String[] args) {
        try {
            TransformerFactory tf = TransformerFactory.newInstance();

            Source documentoXML = new StreamSource("Actores.xml");
            Source documentoXSL = new StreamSource("Actores.xsl");

            String archivoHTML = "Actores.html";

            OutputStream salidaHTML = new FileOutputStream(archivoHTML);
            Transformer transformer = tf.newTransformer(documentoXSL);

            transformer.transform(documentoXML, new StreamResult(salidaHTML));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (TransformerConfigurationException e) {
            throw new RuntimeException(e);
        } catch (TransformerException e) {
            throw new RuntimeException(e);
        }

    }
}
