package A3P2UD2_EJ3;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.*;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.*;

public class A3P2UD2_EJ3 {
    public static void main(String[] args) {
        try {
            String documentoXML = "Alumnos.xml";
            String documentoXSL = "Alumnos.xsl";

            // Configurar el transformador XSLT
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer(new StreamSource(new File(documentoXSL)));

            // Crear la entrada XML para la transformación
            StringWriter writer = new StringWriter();
            transformer.transform(new StreamSource(new File(documentoXML)), new StreamResult(writer));

            // Obtener el XML transformado como cadena
            String transformedXML = writer.toString();

            // Usar SAX para procesar el XML transformado
            SAXParserFactory saxFactory = SAXParserFactory.newInstance();
            SAXParser saxParser = saxFactory.newSAXParser();

            // Convertir el XML transformado en un InputSource para SAX
            InputSource transformedSource = new InputSource(new StringReader(transformedXML));

            // Crear el manejador SAX
            AlumnoManejador manejador = new AlumnoManejador();

            // Analizar el XML transformado con SAX
            saxParser.parse(transformedSource, manejador);

            // Mostrar los resultados
            manejador.mostrarResultados();
        } catch (TransformerConfigurationException e) {
            throw new RuntimeException(e);
        } catch (TransformerException e) {
            throw new RuntimeException(e);
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (SAXException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
