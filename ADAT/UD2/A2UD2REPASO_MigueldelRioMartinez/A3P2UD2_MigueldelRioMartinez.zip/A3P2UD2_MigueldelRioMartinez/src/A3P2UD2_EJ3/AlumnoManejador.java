package A3P2UD2_EJ3;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AlumnoManejador extends DefaultHandler {
    private String currentElement = "";
    private String nombre = "";
    private String nota = "";
    private Map<String, List<String>> notasMap = new HashMap<>();

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        currentElement = qName;
        if ("nota".equals(qName)) {
            // Leer el atributo "valor" de <nota>
            nota = attributes.getValue("valor");
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if ("alumno".equals(qName) && !nombre.isEmpty()) {
            // Agregar el nombre al mapa según la nota
            notasMap.computeIfAbsent(nota, k -> new ArrayList<>()).add(nombre);
            // Reseteamos el nombre para el próximo <alumno>
            nombre = "";
        }
        currentElement = "";
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String content = new String(ch, start, length).trim();
        if (!content.isEmpty()) {
            if ("alumno".equals(currentElement)) {
                nombre = content;
            }
        }
    }

    public void mostrarResultados() {
        System.out.println("NOTAS");
        System.out.println("=======================");
        for (Map.Entry<String, List<String>> entry : notasMap.entrySet()) {
            String nota = entry.getKey();
            List<String> alumnos = entry.getValue();

            int notaNum = Integer.parseInt(nota);

            if (notaNum <= 4) {
                System.out.println("Insuficiente " + nota);
            } else if (notaNum == 5) {
                System.out.println("Suficiente " + nota);
            } else if (notaNum == 6) {
                System.out.println("Bien " + nota);
            } else if (notaNum >= 7 && notaNum <= 8) {
                System.out.println("Notable " + nota);
            } else if (notaNum >= 9) {
                System.out.println("Sobresaliente " + nota);
            }
            System.out.print("                 ");
            System.out.println(String.join("\n                 ", alumnos));
            System.out.println("Num. de alumnos " + alumnos.size());
            System.out.println("-----------------------------");

            //System.out.println("Nota " + nota + ": " + alumnos.size() + " alumno(s) - " + String.join(", ", alumnos));

        }
    }
}
