package A3P2UD2_EJ2;

import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.*;

public class A3P2UD2_EJ2 {
    public static void main(String[] args) {
        try {
            TransformerFactory tf = TransformerFactory.newInstance();

            Source documentoXML = new StreamSource("Hardware.xml");
            Source documentoXSL = new StreamSource("Hardware.xsl");

            String archivoXMLSalida = "HardwareTransformado.xml";

            OutputStream salidaXML = new FileOutputStream(archivoXMLSalida);
            Transformer transformer = tf.newTransformer(documentoXSL);

            transformer.transform(documentoXML, new StreamResult(salidaXML));

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (TransformerConfigurationException e) {
            throw new RuntimeException(e);
        } catch (TransformerException e) {
            throw new RuntimeException(e);
        }
    }
}
